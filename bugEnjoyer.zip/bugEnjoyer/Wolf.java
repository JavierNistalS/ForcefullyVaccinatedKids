package bugEnjoyer;

import aic2021.user.UnitController;

public class Wolf extends MyUnit {

    Wolf(UnitController uc){
        super(uc);
    }

    void playRound(){

    }

}
