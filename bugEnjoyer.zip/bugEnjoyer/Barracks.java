package bugEnjoyer;

import aic2021.user.UnitController;

public class Barracks extends MyUnit {

    Barracks(UnitController uc){
        super(uc);
    }

    void playRound(){

    }

}
