package bugEnjoyer;

import aic2021.user.UnitController;

public class Sawmill extends MyUnit {

    Sawmill(UnitController uc){
        super(uc);
    }

    void playRound(){

    }

}
