package bugEnjoyer;

import aic2021.user.UnitController;

public class Trapper extends MyUnit {

    Trapper(UnitController uc){
        super(uc);
    }

    void playRound(){

    }

}
