package chineseFluKid;

public class P<X, Y> {
    public X x;
    public Y y;
    public P(X x, Y y){
        this.x = x;
        this.y = y;
    }
}