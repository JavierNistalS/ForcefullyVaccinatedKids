package dysenteryKid;

import aic2021.user.UnitController;

public class Farm extends MyUnit {

    Farm(UnitController uc){
        super(uc);
    }

    void playRound()
    {

    }

}
