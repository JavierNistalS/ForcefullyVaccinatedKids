package fullEconomy;

import aic2021.user.UnitController;

public class Quarry extends MyUnit {

    Quarry(UnitController uc){
        super(uc);
    }

    void playRound(){

    }

}
