package rawTechRush;

import aic2021.user.UnitController;

public class Settlement extends MyUnit {

    Settlement(UnitController uc){
        super(uc);
    }

    void playRound(){

    }

}
