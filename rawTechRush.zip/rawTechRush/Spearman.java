package rawTechRush;

import aic2021.user.UnitController;

public class Spearman extends MyUnit {

    Spearman(UnitController uc){
        super(uc);
    }

    void playRound(){

    }

}
